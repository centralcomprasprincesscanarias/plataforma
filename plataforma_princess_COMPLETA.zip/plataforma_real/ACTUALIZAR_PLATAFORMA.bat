@echo off
title ACTUALIZAR PLATAFORMA PRINCESS
color 0A
echo.
echo ============================================
echo   PLATAFORMA PRINCESS - Central de Compras
echo ============================================
echo.

cd /d "D:\PLATAFORMA PRINCESS"

set ACTUALIZADO=0
set ORIGEN=%USERPROFILE%\Downloads

if exist "%ORIGEN%\hub.html" (
    xcopy /Y /Q "%ORIGEN%\hub.html" "." & echo OK: hub.html & set ACTUALIZADO=1
) else ( echo --: hub.html no en Downloads )

if exist "%ORIGEN%\dosier.html" (
    xcopy /Y /Q "%ORIGEN%\dosier.html" "." & echo OK: dosier.html & set ACTUALIZADO=1
) else ( echo --: dosier.html no en Downloads )

if exist "%ORIGEN%\fichas.html" (
    xcopy /Y /Q "%ORIGEN%\fichas.html" "." & echo OK: fichas.html & set ACTUALIZADO=1
) else ( echo --: fichas.html no en Downloads )

if exist "%ORIGEN%\incidencias.html" (
    xcopy /Y /Q "%ORIGEN%\incidencias.html" "." & echo OK: incidencias.html & set ACTUALIZADO=1
) else ( echo --: incidencias.html no en Downloads )

if exist "%ORIGEN%\asignaciones.html" (
    xcopy /Y /Q "%ORIGEN%\asignaciones.html" "." & echo OK: asignaciones.html & set ACTUALIZADO=1
) else ( echo --: asignaciones.html no en Downloads )

if exist "%ORIGEN%\asignaciones.json" (
    xcopy /Y /Q "%ORIGEN%\asignaciones.json" "." & echo OK: asignaciones.json & set ACTUALIZADO=1
) else ( echo --: asignaciones.json no en Downloads )

if exist "%ORIGEN%\admin.html" (
    xcopy /Y /Q "%ORIGEN%\admin.html" "." & echo OK: admin.html & set ACTUALIZADO=1
) else ( echo --: admin.html no en Downloads )

echo.
if %ACTUALIZADO%==0 (
    echo ERROR: No se encontro ningun fichero en Downloads
    pause & exit
)

git add .
git commit -m "Actualizacion plataforma %date%"
git push origin main

echo.
if %ERRORLEVEL% == 0 (
    echo ============================================
    echo   OK - SUBIDO A GITHUB
    echo   Disponible en 1-2 min:
    echo   centralcomprasprincesscanarias.github.io
    echo ============================================
) else (
    echo ERROR al subir a GitHub
)
echo.
pause
