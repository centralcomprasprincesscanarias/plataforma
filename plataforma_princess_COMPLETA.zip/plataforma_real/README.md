# Plataforma Princess · Central de Compras Canarias

## Archivos

| Archivo | Descripción |
|---------|-------------|
| `hub.html` | Pantalla principal — acceso a todos los módulos + estado Supabase |
| `dosier.html` | Catálogo de artículos con pedidos — datos desde GitHub |
| `fichas.html` | Portal de fichas técnicas — datos desde Supabase |
| `incidencias.html` | Registro e historial de incidencias — Supabase backend |
| `asignaciones.html` | Consulta de asignaciones por familia |
| `asignaciones.json` | Datos de asignaciones |
| `admin.html` | Panel de administración |
| `corona0.ico` | Favicon |
| `ACTUALIZAR_PLATAFORMA.bat` | Copia Downloads → carpeta y hace git push (todos los módulos) |
| `ACTUALIZAR_ASIGNACIONES.bat` | Copia solo asignaciones.html + asignaciones.json y hace git push |

## Infraestructura

- **GitHub Pages**: `https://centralcomprasprincesscanarias.github.io/princess-data/`
- **Fichas Técnicas repo**: `https://centralcomprasprincesscanarias.github.io/fichas-tecnicas/`
- **Supabase**: `https://ifiwuloipapsezmssyda.supabase.co`
- **Datos JSON artículos**: `https://raw.githubusercontent.com/centralcomprasprincesscanarias/princess-data/main/`

## Cómo actualizar

### Todos los módulos
1. Descarga el/los HTML desde Claude
2. Ejecuta `ACTUALIZAR_PLATAFORMA.bat`

### Solo asignaciones
1. Descarga `asignaciones.html` y/o `asignaciones.json`
2. Ejecuta `ACTUALIZAR_ASIGNACIONES.bat`
