@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0Crear_Acceso_Directo_Plataforma.ps1"
