param(
    [string]$Url = "https://centralcomprasprincesscanarias.github.io/plataforma/hub.html"
)

$baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$shortcutPath = Join-Path $baseDir "Plataforma Princess.lnk"
$iconPath = Join-Path $baseDir "icono_plataforma_princess.ico"

$edgeCandidates = @(
    "$Env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe",
    "$Env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$Env:LocalAppData\Microsoft\Edge\Application\msedge.exe",
    "$Env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe",
    "$Env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "$Env:LocalAppData\Google\Chrome\Application\chrome.exe"
)

$browserPath = $edgeCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $browserPath) {
    Write-Host "No se encontró Edge ni Chrome en este equipo." -ForegroundColor Red
    exit 1
}

$wsh = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $browserPath
$shortcut.Arguments = "--app=""$Url"""
$shortcut.WorkingDirectory = $baseDir

if (Test-Path $iconPath) {
    $shortcut.IconLocation = "$iconPath,0"
}

$shortcut.Save()

Write-Host "OK: acceso directo creado en $shortcutPath" -ForegroundColor Green
